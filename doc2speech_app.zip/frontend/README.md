# Frontend (Next.js)

Simple React/Next.js UI to upload documents and play generated audio.
