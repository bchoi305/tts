# Document-to-Speech App

Generated starter repo for English TTS using VibeVoice via fal.ai.
